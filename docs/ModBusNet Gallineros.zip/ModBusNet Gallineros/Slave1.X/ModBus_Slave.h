/*********************************************************************************************************
 ********************************************************************************************************* 
 *  FILE:       Modbus_Slave.h
 *  AUTHOR:     Ing. Alejandro Gregore - Adaptado a XC8 por Ing.Ivan Talijancic
 *  PROGRAMA:   Defines, Variables y Funciones de la Implementacion del ModBus Slave
 *  COMPILADOR: XC8 V1.32
 *  IDE:        MPLABX    
 *  FECHA:      Created on 15 de octubre de 2015, 08:43
 ********************************************************************************************************
 ********************************************************************************************************/

//********************************************************************************************************
//***************************************INCLUSION DE LIBRERIAS*******************************************
#include <stdint.h>
#include <GenericTypeDefs.h>

//********************************************************************************************************

//********************************************************************************************************
//***********************************************DEFINES**************************************************
#define make16(a,b) (((WORD) (a)) | (((WORD) (b))) << 8)
#define m_asr16(x,y) ((x >> y) | (((int)x < 0)?((int)-1 << ((8*sizeof(x))-y)):0))
//********************************************************************************************************

//********************************************************************************************************
//******************************DEFINES DE PRECOMPILACI�N*************************************************
//Defino que timer ocupo para el time out del ModBus serie
//#define useTMR2ModBus
#define useTMR1ModBus
//********************************************************************************************************

//********************************************************************************************************
//***********************DECLARACION DE VARIABLES Y CONSTANTES********************************************
//Constantes comando trama modbus
const UINT8  ModbusAdd=0;                //posicion de la direccion en la trama modbus
const UINT8  ModbusCmd=1;                //posicion del comando en la trama modbus
const UINT8  ModbusIni=2;                //posicion del primer registro solicitado en trama modbus 2 bytes
const UINT8  ModbusCant=4;               //posicion de la cantidad de registros en la trama modbus 2 bytes
const UINT8  ModbusBCount=2;             //posicion de la cantidad de bytes en la respuesta modbus

/*********************************************************************
* RECORDAR:
*           Si cambiamos el tama�o de los buffers de recepci�n y 
*           transmici�n, debemos tmb cambiar la variable lenbuff,
*           para que funcione la libreria.
***********************************************************************/
const UINT8  lenbuff=20;
UCHAR8  Txbuff[20];                      //Buffer de transmicion ModBus
UCHAR8  Rxbuff[20];                      //Buffer de recepcion ModBus
UCHAR8  rxPuntero=0x00;                  //�ndice: siguiente char en cbuff
UCHAR8  rcvchar=0x00;                    //Ultimo caracter recibido
UCHAR8  txlen=0;                         //Largo del buffer de transmicion ModBus
UCHAR8  txpoint=0;
                  
UINT8 ModbusAddress=0x02;                 //direccion del esclavo

//BANDERAS
BIT  flagcommand=0;                       // Flag para indicar comando disponible
BIT  fParami=0;                           // Indica que el comando es par este esclavo
BIT  fFinTrama=0;                         // Paso el tiempo de espera para considerar que termino la trama 3 bit time para RTU 
BIT  flg_EndModBusRx=0;                    //Flag para indicar finalizaci�n de recepci�n modbus
//********************************************************************************************************

//********************************************************************************************************
//******************************DECLARACION DE FUNCIONES (Prototipos)*************************************
//Funciones
UINT16 CRC_Calc(char *msg,char msgLen);
void ModBusRX(char data);
void ModBusTX(void);
void ModBus_exe(void);
void ModBus_Exep(UINT8 SlvAdd,UINT8 ExepNro);
void Modbus_RespOK(UINT8 SlvAdd, UINT8 Cmd);
void inicbuffRX(void);
void inicbuffTX(void);
void FinModBusRx(void);
void IniModBusHRs(void);

//********************************************************************************************************