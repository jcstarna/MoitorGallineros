/*********************************************************************************************************
 ********************************************************************************************************* 
 *  FILE:       Modbus.c
 *  AUTHOR:     Ing. Alejandro Gregore - Adaptado a XC8 por Ing.Ivan Talijancic
 *  PROGRAMA:   Definici�n o implementacion de funciones ModBus Slave
 *  COMPILADOR: XC8 V1.32
 *  IDE:        MPLABX    
 *  FECHA:      Created on 15 de octubre de 2015, 08:43
 ********************************************************************************************************
 ********************************************************************************************************/

//********************************************************************************************************
//***************************************INCLUSION DE LIBRERIAS*******************************************
#include <stdint.h>
#include <xc.h>
#include <GenericTypeDefs.h>
#include "main.h"
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/eusart.h"
#include "ModBus_Slave.h"


//********************************************************************************************************

//********************************************************************************************************
//*****************************************DEFINICIONES DE FUNCIONES**************************************

/*************************************************************************************
 * FUNCION:     CRC_Calc (int *msg,int msgLen)
 * DESCRIPCION: Calculo el Cheksum del mensaje recibido
 * ARGUMENTOS:  Mensaje, Longitud del mensaje
 * RETURN:      CRC  
 ************************************************************************************/
UINT16 CRC_Calc(char *msg,char msgLen)
{
    UINT16 crc;
    crc=0xffff;
    UINT8 i=0 ;   //contador de bytes
    UINT8 j=0;    //contador de bits
    UINT16 dato=0;
    
    for (i = 0; i <= msgLen; i++)
    {   
        //bucle para cada uno de los bytes del mensaje
        dato = *(msg+i);
        crc = crc^dato;
        for (j = 0; j <= 7; j++)
        { 
            if (crc & 0x0001 != 0) 
            {
                crc >>= 1;
                crc ^= 0xA001;
            } 
            else 
            {
                crc >>= 1;
            }
        }    
    }
    fParami=0;
    return crc;
}//End CRC_Calc (int *msg,int msgLen)
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     ModBusRX ()
 * DESCRIPCION: Al llegar un dato nuevo al buffer de RX, se envia a esta rutina, 
 *              si el dato es para este esclavo se lo procesa, de otra forma 
 *              se rechaza para reducir tiempo
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void ModBusRX(char data)
{
    //Si el dato recibido es el primero y es la direccion de esclavo mia
    if ((rxPuntero == 0) && (data == ModbusAddress))
    {
       fParami = 1;   //Seteo el flag que indica que debo recibir el resto de la trama
    }
    //Si el dato recibido es el primero y no coincide con mi direccion de esclavo
    else if ((rxPuntero == 0) && (data =! ModbusAddress))
    {
       fParami = 0;      //No le doy bola al resto del mensaje
    }
    //Si el msg era para mi, voy guardandolo en el buffer de recepcion 
    if(fParami)
    {
      Rxbuff[rxPuntero] = data;
    } 
    //Incremento el puntero de recepci�n
    rxPuntero++;
 }//End ModBusRX
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     void FinModBusRx(void)
 * DESCRIPCION: Llamo esta funcion cuando finalizo la recepci�n de un trama modbus
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void FinModBusRx(void)
{
    UINT16 CRC = 0;
    UINT16 CRC_Leido = 0;
    //Si la direccion coincidio con la mia
    if(fParami)
    {   
        //Calculo checksum de dato recibido                     
        CRC = CRC_Calc(&Rxbuff[0],rxPuntero-3);                       
        CRC_Leido = make16(Rxbuff[rxPuntero-2],Rxbuff[rxPuntero-1]);
        //Si coinciden los CRC, se que tengo un comando pendiente
        if(CRC_Leido == CRC)
        {
            flagcommand = 1;
        }
    }
    else
    {
        inicbuffRX();
        rxPuntero = 0;
    }
}//End void FinModBusRx(void)
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     ModBusTX ()
 * DESCRIPCION: Envio de datos, respuestas modbus por interrupcion TBE USART
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void ModBusTX(void)
{
   //Mientras tenga datos para transmitir en el buffer 
   if(txlen-- > 0)
   {
        putch(Txbuff[txpoint]);
        txpoint++;
   }
   else
   {
        PIE1bits.TXIE = 0;    //Disable Transmit Interrupts
        txlen = 0;
        inicbuffTX();
   }
}//End ModBusTX()
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     ModBus_exe()
 * DESCRIPCION: Analiza el buffer de recepcion y elavora respuesta
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void ModBus_exe(void)
{
    //Declaraci�n de variables globales
    char        comando = 0;
    UINT16      cant = 0;
    UINT16      offset = 0;
    UINT16      *DirIni;
    UINT8       i = 0;
    UINT16_VAL  CRC;
    UINT16_VAL  TempReg;
    
    //Inicializaci�n de variables
    CRC.Val = 0;
    TempReg.Val = 0;
    flagcommand = 0;
    comando = Rxbuff[ModbusCmd];                               //recupero comando
    offset = make16(Rxbuff[ModbusIni+1],Rxbuff[ModbusIni]);    //recupero direccion del registro como offset del inicio de la memoria
    cant = make16(Rxbuff[ModbusCant+1],Rxbuff[ModbusCant]);    //recupero cantidad de registros para comando 0x03
    DirIni = &HR.CMD + offset;
    
    //Ejecuto el comando modbus
    switch (comando)
    {
         //Comando ModBus 03: Leer Multiples Registros
         case 0x03:                                 
            //armo respuesta modubs para comando 0x03
            Txbuff[ModbusAdd] = ModbusAddress;        //Direccion esclavo; 
            Txbuff[ModbusCmd] = comando;              //Comando
            txlen = cant*2;                           //Largo del buffer de transimicion
            Txbuff[ModbusBCount] = txlen;             //Cantidad de Bytes
            //busco los datos que estan en memoria
            for (i = 1 ;i <= cant; i++)
            {      
              TempReg.Val = *(DirIni);
              Txbuff[i*2+1] = TempReg.byte.HB;
              Txbuff[i*2+2] = TempReg.byte.LB;
              DirIni++;
            }
            CRC.Val = CRC_Calc(&Txbuff[0],txlen+2);     //Calculo checksum del mensaje
            //cargo CRC en buffer
            Txbuff[txlen+3] = CRC.byte.LB;          //Checksum parte alta
            Txbuff[txlen+4] = CRC.byte.HB;          //Checksum parte baja
            txlen = txlen+5;                          //Cantidad de bytes en el buffer de transmision
            break;
         case 0x04:
            break;
            
         //Comando ModBus 0x06: Escribir un registro
         case 0x06:
            //00 Slave Address
            //01 ModBus Cmd
            //02 DirH
            //03 DirL
            //04 DataH
            //05 DataL
            TempReg.byte.HB = Rxbuff[4];
            TempReg.byte.LB = Rxbuff[5];
            *(DirIni) = TempReg.Val;
            //Armo respuesta que es repetir la pregunta
            Modbus_RespOK(ModbusAddress, comando);           
            break; 
            
         //Comando ModBus 0x10: Escribir multiples registros
         case 0x10:
            for (i=1;i<=cant;i++)
            {      
                TempReg.byte.HB = Rxbuff[i*2+5];
                TempReg.byte.LB = Rxbuff[i*2+6];
                *(DirIni) = TempReg.Val;
                DirIni++;
            }
            //Armo respuesta
            Modbus_RespOK(ModbusAddress, comando);
            break;            
         case 0x11:
            break;
    }
    txpoint = 0;
    //Hago el envio de la respuesta
    PIE1bits.TXIE = 1;                                //Enable Transmit Interrupts
}//End ModBus_exe()
/*************************************************************************************/

/*************************************************************************************
 * FUNCION:     ModBus_Exep(int SlvAdd,int ExepNro)
 * DESCRIPCION: Respuesta de error
 * ARGUMENTOS:  SlaveAddress and ModBusCmd
 * RETURN:      None    
 ************************************************************************************/
void ModBus_Exep(UINT8 SlvAdd,UINT8 ExepNro)
{
    UINT16 CRC=0;
    //01 Illegal function
    //02 Illegal Data address
    //03 Illegal Data Value
}
/***********************************************************************************/

/*************************************************************************************
 * FUNCION:     Modbus_RespOK(int SlvAdd,int Cmd)
 * DESCRIPCION: Generar respuesta de OK en para los comandos procesados
 * ARGUMENTOS:  SlaveAddress and ModBusCmd
 * RETURN:      None    
 ************************************************************************************/
void Modbus_RespOK(UINT8 SlvAdd,UINT8 Cmd)
{
    //Declaracion de variables locales
    UINT16_VAL  CRC;

    //Armo el msj de respuesta
    Txbuff[ModbusAdd] = SlvAdd;                       //Direccion esclavo; 
    Txbuff[ModbusCmd] = Cmd;                          //Comando
    Txbuff[ModbusIni] = Rxbuff[ModbusIni];            //Direccion del registro a escribir HB
    Txbuff[ModbusIni+1] = Rxbuff[ModbusIni+1];        //Direccion del registro a escribir LB
    Txbuff[ModbusCant] = Rxbuff[ModbusCant];          //Writte Value HB
    Txbuff[ModbusCant+1] = Rxbuff[ModbusCant+1];      //Writte Value LB
    CRC.Val = CRC_Calc(&Txbuff[0],5);                     //Calculo checksum del mensaje
    //cargo CRC enbbuffer
    Txbuff[6] = CRC.byte.LB;                          //Checksum parte baja
    Txbuff[7] = CRC.byte.HB;                          //Checksum parte alta
    txlen = 8;
}
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     inicbuffRX()
 * DESCRIPCION: Clear el buffer de recepcion modbus
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void inicbuffRX(void)
{               
   UINT8 i;
   for(i=0;i<lenbuff;i++)
   {                          
      Rxbuff[i] = 0x00;                               
   }
   rxPuntero = 0x00;                    
}
/************************************************************************************/

/*************************************************************************************
 * FUNCION:     inicbuffTX()
 * DESCRIPCION: Clear el buffer de Trasmicion modbus
 * ARGUMENTOS:  None
 * RETURN:      None    
 ************************************************************************************/
void inicbuffTX(void)
{                   
   UINT8 i;
   for(i = 0; i < lenbuff ;i++)
   {             
       Txbuff[i] = 0;
   }
   txpoint = 0x00; 
   txlen = 0x00;
}
/************************************************************************************/

/*******************************************************************************
 * FUNCION:     void IniModBusHRs(UINT8 cant)
 * DESCRIPCION: Funcion para inicializar en cero los HR modbus
 * ARGUMENTOS:  UINT8 cant = cantidad de registros a inicializar
 * RETURN:      None    
 *******************************************************************************/
void IniModBusHRs(void)
{
    //Declaracion de varaibles globales
    UINT16 *pointer;
    UINT8 i;
    UINT8 cant;
    
    //Determino la cantidad de registros a inicializar
    cant = sizeof(HR)/2;
    //Inicializo el puntero al primer HR
    pointer = &HR.CMD;
    
    for(i=1 ; i <= cant ; i++)
    {
        *pointer = 0x0000;
       pointer++; 
    }
}//End void IniModBusHRs(void)
//******************************************************************************

//********************************************************************************************************