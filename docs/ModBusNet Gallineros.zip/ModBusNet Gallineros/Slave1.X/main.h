/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:                main.h
 * Author:              Ing. Talijancic Iv�n
 * Comments:            Declaraciones de variables y funciones         
 * Revision history:    v1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef MAIN_H
#define	MAIN_H

//******************************************************************************
//***********************INCLUSI�N DE LIBRERIAS*********************************
#include <xc.h> // include processor files - each processor file is guarded.  
#include <GenericTypeDefs.h>
//******************************************************************************

//******************************************************************************
//********************************DEFINES***************************************
#define __EXTENSION
//#define UseDebuggerPIN
//******************************************************************************

//******************************************************************************
//*********DECLARACI�N E INICIALIZACI�N DE VARIABLES Y CONSTANTES***************
//CONSTANTES 
const UINT16 kDelayLED=500;
const UINT16 kPWM_Pasos=1000;       //Constante de cantidad de pasos del PWM por soft (en x0ms)

//VVARIABLES
UINT16 DelayLED=500; 

//PWM por Sfot
UINT16 pasos=0;                     //Inicializo los pasos en cero, incrementa cada 250ms
UINT16 pwm_duty=500;                //Inicializo el pwm al 50%  (en x10ms)



//BANDERAS
BIT flg_ToggleLED=0;


//ESTRUCTURAS
/*********************************************************
 ***********HOLDING REGISTERS MODBUS SERIE****************
 ********************************************************/
struct
{
    //Modbus
    UINT16  CMD     ;   //HR - 40001 - Registro de comandos 
    UINT16  TMR0    ;   //HR - 40002 - Registro de Prueba
}HR;
//********************************************************

//******************************************************************************

//******************************************************************************
//************************DECLARACI�N DE FUNCIONES******************************

/**
    <p><b>Function prototype:</b> void do_pwm(void) </p>
  
    <p><b>Summary:</b> Funcion para ejecuatar un PWM por soft </p>

    <p><b>Description:</b> None </p>

    <p><b>Precondition:</b> None </p>

    <p><b>Parameters:</b> None </p>

    <p><b>Returns:</b> None </p>

    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
void do_pwm(void);

/**
    <p><b>Function prototype:</b> void ModBusCMD(void) </p>
  
    <p><b>Summary:</b> Funci�n para ejecuatar comandos a traves de Modbus </p>

    <p><b>Description:</b> None </p>

    <p><b>Precondition:</b> None </p>

    <p><b>Parameters:</b> None</p>

    <p><b>Returns:</b> None </p>

    <p><b>Example:</b> </p>
    <code>
        ModBusCMD(void);
    </code>

    <p><b>Remarks:</b></p>
 */
void ModBusCMD(void);

//******************************************************************************

// Comment a function and leverage automatic documentation with slash star star
/**
    <p><b>Function prototype:</b></p>
  
    <p><b>Summary:</b></p>

    <p><b>Description:</b></p>

    <p><b>Precondition:</b></p>

    <p><b>Parameters:</b></p>

    <p><b>Returns:</b></p>

    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation



#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* MAIN_H */

