/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - 4.15.1
        Device            :  PIC12F1572
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.40
*/

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

//******************************************************************************
//***********************INCLUSI�N DE LIBRERIAS*********************************
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "ModBus_Slave.h"
#include "button.h"
//******************************************************************************

//******************************************************************************
//********************FUNCI�N PRINCIPAL DEL PROGRAMA****************************
void main(void)
{
    //**************************************************************************
    //****************INICIALIZACI�N SISTEMA E INTERRUPCIONES*******************
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    //**************************************************************************
    
    //**************************************************************************
    //************************ME DEDICO A OTRAS TAREAS**************************
    
    /*Pongo en bajo las salidas*/
    LATA = 0x00;
    
    /*Apago el  led de test*/
    LED_TEST_SetHigh();
    
    //Inicializo los HR de ModBus
    IniModBusHRs();
    
    /*Buffers de ModBus*/
    inicbuffRX();                                
    inicbuffTX();

    //**************************************************************************
    
    //**************************************************************************
    //************************BUCLE INFINITO while(1)***************************
    while (1)
    {
        HR.TMR0 = TMR0;
        
        /***********************************************************************
         ****************************MODBUS SERIE*******************************
         **********************************************************************/
        //Si termino la recepci�n de una trama ModBus
        if(flg_EndModBusRx)
        {
            flg_EndModBusRx=0;
            FinModBusRx();
        }
        //Si tengo un comando ModbusPendiente, lo proceso
        if(flagcommand)
        {
            LED_TEST_Toggle();
            flagcommand=0;
            ModBus_exe();
            inicbuffRX();
        }
        //Si tengo el registro modbus de comando cargado, ejecuto el comando
        if(HR.CMD!=0)
        {
            ModBusCMD();
        }
        //**********************************************************************
        
        /***********************************************************************
         ************************DEBUGGER MCU RUN*******************************
         **********************************************************************/
        #ifdef UseDebuggerPIN
            if(flg_ToggleLED)
            {
                flg_ToggleLED=0;
                LED_TEST_Toggle();
            }
        //**********************************************************************
        #endif
    }//End while(1)
    //**************************************************************************
    
}//End void main(void)
//******************************************************************************

//******************************************************************************
//**********************DEFINICI�N DE FUNCIONES*********************************

/*******************************************************************************
 * FUNCION:     void ModBusCMD(void)
 * DESCRIPCION: Funcion para ejecutar comandos a traves de modbus
 * ARGUMENTOS:  None
 * RETURN:      None    
 *******************************************************************************/
void ModBusCMD(void)
{
    switch(HR.CMD)
    {
        default:
            break;
    }
    
    //Limpio el registro de comando
    HR.CMD=0x0000;
}//End void ModBusCMD(void)
//******************************************************************************

/*******************************************************************************
 * FUNCION:     void do_pwm(void)
 * DESCRIPCION: 
 * ARGUMENTOS:  None
 * RETURN:      None    
 *******************************************************************************/
void do_pwm(void)
{    
    if((pasos <= pwm_duty) /*&& !OutputPORT*/)
    {
        
    }
    //else
    if((pasos > pwm_duty) /*&& OutputPORT*/)
    {
        
    }
}
//******************************************************************************
//End void do_pwm(void)

//Header Example
/*******************************************************************************
 * FUNCION:     
 * DESCRIPCION: 
 * ARGUMENTOS:  None
 * RETURN:      None    
 *******************************************************************************/

//******************************************************************************

//******************************************************************************
/**
 End of File
*/